# Orbit OS + Scramjet browser

A console-style home screen (Games / Media tabs, search, settings, Snake) with a
working web browser built in. The browser runs on [Scramjet](https://github.com/MercuryWorkshop/scramjet)
(service worker + WASM rewriter), with a Wisp WebSocket server doing the network
requests. Server and browser both live in this one project, so there is nothing else to host.

## Run it locally

    npm install
    npm start

Open http://localhost:8080, press any key, then go to Media -> Browser.
(Service workers work on `localhost` over plain HTTP.)

## Deploy it

Service workers need **HTTPS** on any real domain, and the host must allow WebSockets.

- **Docker:** `docker build -t orbit-os . && docker run -p 8080:8080 orbit-os`
- **Render / Railway / Fly.io:** create a Node (or Docker) web service from this folder.
  Start command: `npm start`. They provide HTTPS for you.
- **VPS:** run `npm start` behind nginx or Caddy with a TLS certificate. Pass WebSocket
  upgrades through for the `/wisp/` path.

The port comes from the `PORT` environment variable (default 8080).

## Settings (environment variables)

| Variable | Effect |
| --- | --- |
| `PORT` | Port to listen on |
| `DNS_SERVERS` | Comma-separated DNS servers for Wisp, e.g. `1.1.1.1,1.0.0.1` |
| `ALLOW_LOCAL=1` | Lets the proxy reach private/loopback addresses. Testing only. Never use on a public server. |

## Notes

- Sites that use CAPTCHAs or heavy bot checks often fail from datacenter IP addresses.
- A public proxy gets abused. Keep yours private or put it behind a password or firewall.
- Pinned to Scramjet v1.1.0, the version the official Scramjet-App demo uses.
- Based on MercuryWorkshop/Scramjet-App, so this project is licensed AGPL-3.0 (see LICENSE).
